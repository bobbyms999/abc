import { Component, OnInit } from '@angular/core';
import {FormControl, Validators, FormBuilder, FormGroup} from '@angular/forms';
import { ApiService } from './../api.service';
import { AuthService } from './../auth.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  toggleType = 'password';
  showForgotPasswordField = false;
  get f() { return this.loginForm.controls; }

  constructor(
    private apiService: ApiService,
    private formBuilder: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private snackBar: MatSnackBar
  ) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
     // userName: ['', Validators.required],
      password: ['', Validators.required],
      email: ['', [Validators.required]],
  });
  }

  showPassword() {
    setTimeout(() => {
      this.toggleType = 'password';
    }, 1000);
    this.toggleType = 'text';
  }

  loginUser() {
    /* console.log('inside login')
    if (this.loginForm.value.userName === 'admin' || this.loginForm.value.email === 'admin') {
      console.log('inside true');
      this.authService.setLoginState();
      localStorage.setItem('accredilinkUser', 'admin');
      this.router.navigateByUrl('preEmpScreening');
    } else {
      console.log('inside false');
      this.authService.removeLoginState();
    } */
    const requestBody = { emailId: this.loginForm.value.email, password: this.loginForm.value.password, token: null };
    this.apiService.loginUser(requestBody).subscribe(data => {
      console.log(data);
      const response: any = data;
      if (response.code === 1) {
        this.openSnackBar(response.message, 'successSnackbar');
        this.authService.setLoginState();
        if (response.sessionId) {
          localStorage.setItem('accredilinkUser', response.sessionId);
        } else {
          localStorage.setItem('accredilinkUser', 'admin');
        }
        this.router.navigateByUrl('preEmpScreening');
      } else if (response.code === 0) {
        this.openSnackBar(response.message, 'errorSnackbar');
      }
    }, (error) =>  {
      this.openSnackBar(error.error.message, 'errorSnackbar');
    }, () => {
      console.log('Login complete');
    });
  }

  forgotPassword() {
    this.showForgotPasswordField = true;
  }

  sendEmail() {
    const requestBody = { emailId: this.loginForm.value.email, password: null, token: null };
    this.apiService.sendEmailForForgotPassword(requestBody).subscribe(data => {
      console.log(data);
      const response: any = data;
      if (response.code === 1) {
        this.openSnackBar('Email sent, Please login', 'successSnackbar');
        this.router.navigateByUrl('login');
        this.showForgotPasswordField = false;
        Object.keys(this.loginForm.controls).forEach(key => {
          this.loginForm.controls[key].setErrors(null);
        });
      } else if (response.code === 0) {
        this.openSnackBar('Failed while sending email', 'errorSnackbar');
      }
    }, (error) =>  {
      this.openSnackBar(error.error.message, 'errorSnackbar');
    }, () => {
      console.log('Email sending complete');
    });
   /*  this.showForgotPasswordField = false;
    this.loginForm.reset({email: '', password: ''}); */
  }

  cancelFromForgotPassword() {
    this.loginForm.reset();
    Object.keys(this.loginForm.controls).forEach(key => {
      this.loginForm.controls[key].setErrors(null);
    });
    this.showForgotPasswordField = false;
  }

  openSnackBar(message, className) {
    this.snackBar.open(message, null, { duration: 5000, panelClass: [className], horizontalPosition : 'right' });
  }

}
