import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { ApiService } from './../../api.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {
  toggleType1 = 'password';
  createEmployeeForm: FormGroup;
  maxDate = new Date();
  showSpinner = false;
  agencyId=null;
  get f() { return this.createEmployeeForm.controls; }


  /* agencyList = [
    {agencyId: 12, agencyName: 'Apollo'},
    {agencyId: 34, agencyName: 'MRF'},
    {agencyId: 56, agencyName: 'Michellin'},
    {agencyId: 78, agencyName: 'Ceat'}
  ];
 */
  agencyList = [];

  constructor(private apiService: ApiService, private formBuilder: FormBuilder,  private snackBar: MatSnackBar, private router: Router) { }

  ngOnInit() {
   this.initiateForm();
   this.fetchAgencyList();
  }

  initiateForm() {
    this.createEmployeeForm = this.formBuilder.group({
      ssnNumber: ['', Validators.required],
      firstName: ['', Validators.required],
      middleName: '',
      lastName: ['', Validators.required],
      emailId: ['', [Validators.required, Validators.email]],
      dateOfBirth: ['', Validators.required],
      agencyId: ['', Validators.required]
  });
  }

  fetchAgencyList() {
    this.showSpinner = true;
    const sub = this.apiService.fetchAgencyList().subscribe(data => {
      console.log(data);
      const response: any = data;
      this.showSpinner = false;
      this.agencyList = response;
    }, (error) =>  {
      console.log(error);
      this.openSnackBar(error.message, 'errorSnackbar');
      this.showSpinner = false;
    }, () => {
      console.log('agency fetch success');
      this.showSpinner = false;
    });
  }

  showPassword1() {
    setTimeout(() => {
      this.toggleType1 = 'password';
    }, 1000);
    this.toggleType1 = 'text';
  }

  createEmployee() {
    console.log(this.createEmployeeForm.value);
    this.showSpinner = true;
    const requestBody = this.createEmployeeForm.value;
    delete requestBody['agencyId']; 
    requestBody.agency = [{agencyId: this.agencyId}]
    const sub = this.apiService.createEmployee(requestBody).subscribe(data => {
      console.log(data);
      const response: any = data;
      this.openSnackBar(response.message, 'successSnackbar');
      this.showSpinner = false;
      this.initiateForm();
      this.router.navigateByUrl('preEmpScreening');
    }, (error) =>  {
      console.log(error);
      this.openSnackBar(error.message, 'errorSnackbar');
      this.showSpinner = false;
     // this.initiateForm();
    }, () => {
      console.log('create employee success');
      this.showSpinner = false;
    });
  }

  openSnackBar(message, classnNumberame) {
    this.snackBar.open(message, null, { duration: 5000, panelClass: [classnNumberame], horizontalPosition : 'right' });
  }

  resetForm() {
    this.showSpinner = false;
  /*   this.createEmployeeForm.reset();
    Object.keys(this.createEmployeeForm.controls).forEach(key => {
      this.createEmployeeForm.controls[key].setErrors(null);
    }); */
    this.initiateForm();
  }

  agencyChange(event) {
	this.agencyId=event;
    console.log(event)
  }
}
