package com.accredilink.bgv.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.accredilink.bgv.service.BgCheckService;
import com.accredilink.bgv.util.ResponseObject;

@RestController
@RequestMapping("/submit")
public class BgCheckController {


	@GetMapping("/bgcheck")
	public String check(@PathVariable int employeeId) {

	


		return "success";
	}


	public boolean verifyWithSSN(String lastName, String firstName, String ssn) {

			// TODO Auto-generated method stub
		 
		    String resutlStr = "SSN/EIN Does Not Match!!";
		    boolean matchFound = false;

			 
			// Initialize browser
			WebDriver driver=new ChromeDriver();
			 
			driver.manage().window().maximize();
			JavascriptExecutor js = (JavascriptExecutor) driver;

			// Launch URL
			driver.get("https://oig.hhsc.state.tx.us/oigportal/EXCLUSIONS.aspx");
			driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);

			WebElement lastNameField = driver.findElement(By.id("dnn_ctr423_Search_txtLast1"));
			lastNameField.clear();
			lastNameField.sendKeys(lastName);

			WebElement firstNameField = driver.findElement(By.id("dnn_ctr423_Search_txtFirst1"));
			firstNameField.clear();
			firstNameField.sendKeys(firstName);

			WebElement submit = driver.findElement(By.id("dnn_ctr423_Search_btnSearch"));
			submit.click();
			driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);

			List<WebElement> rowcount = driver
					.findElements(By.xpath("//*[@id=\"dnn_ctr423_Search_gv_Results\"]/tbody/tr"));

			System.out.println(rowcount.size());
			js.executeScript("window.scrollBy(0,1000)");

			for (int i = 0; i <= rowcount.size(); i++) {

				try {

					WebElement rowlink = driver
							.findElement(By.id("dnn_ctr423_Search_gv_Results_imgBtnViewSSNVerification_" + i + ""));

					rowlink.click();
					driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
					/*WebElement clikonssn = driver
							.findElement(By.id("dnn_ctr423_Search_gv_Results_wmepubsvfy_" + i + "_text"));*/
					WebElement clikonssn = driver
							.findElement(By.id("dnn_ctr423_Search_gv_Results_wmeSSN_" + i + "_text"));
					clikonssn.click();
					clikonssn.sendKeys(ssn);
					driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);

					WebElement clickonverify = driver
							.findElement(By.id("dnn_ctr423_Search_gv_Results_btnVerifySSN_" + i + ""));
					clickonverify.click();

					WebElement Results = driver.findElement(By.id("dnn_ctr423_Search_gv_Results_lblVerifiedResult_0"));
					System.out.println(Results.getText());
					
					if(Results.getText() != null && !Results.getText().equalsIgnoreCase(resutlStr)) {
						matchFound = true;
						break;
					}
					else{
						matchFound=false;
					}
					
					driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);

					Thread.sleep(3000);
				} catch (Exception e) {
					System.out.println("Exception Handled");

				}

			}
			//driver.manage().window().maximize();
			driver.quit();	
		  return matchFound;
	 }



	public static void takescreenshot(WebDriver driver,String filename) throws IOException
	{
		TakesScreenshot ts=(TakesScreenshot)driver;
		File source=	ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source, new File(".//sceenshots//"+filename+".png"));
	}



}
