import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

const baseUrl = 'http://localhost:2020';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }

  registerUser(userDetails): Observable<any> {
    return this.http.post(`${baseUrl}/accredilinkdb/user/register`, userDetails);
  }

  loginUser(userDetails): Observable<any> {
    return this.http.post(`${baseUrl}/accredilinkdb/user/login`, userDetails);
  }

  sendEmailForForgotPassword(requestBody) {
    return this.http.post(`${baseUrl}/accredilinkdb/user/forgotpassword`, requestBody);
  }

  resetPassword(requestBody) {
    return this.http.post(`${baseUrl}/accredilinkdb/user/resetpassword`, requestBody);
  }

  createEmployee(requestBody) {
    return this.http.post(`${baseUrl}/accredilinkdb/employee/create`, requestBody);
  }
  
  updateEmployee(requestBody) {
    return this.http.post(`${baseUrl}/accredilinkdb/employee/update`, requestBody);
  }

  fetchEmployeeList() {
    return this.http.get(`${baseUrl}/accredilinkdb/employee/fetchallemployees`);
  }

  deleteEmployee(employeeId) {
    return this.http.get(`${baseUrl}/accredilinkdb/employee/delete/${employeeId}`);
  }

  fetchAgencyList() {
    return this.http.get(`${baseUrl}/accredilinkdb/employee/fetchallagencies`);
  }

  fetchDesignationList() {
    return this.http.get(`${baseUrl}/accredilinkdb/employee/fetchalldisciplines`);
  }

  fetchEmployeeBgList() {
    return this.http.get(`${baseUrl}/accredilinkdb/submit/bgverify`);
  }

  fetchBgvProof(employeeId) {
   return this.http.get(`${baseUrl}/accredilinkdb/submit/bgproof/${employeeId}`);
  // return this.http.get(`assets/bgvProof.json`);
  }

  submitBg() {
    return this.http.get(`${baseUrl}/accredilinkdb/submit/bgsubmit`);
  }

}

