import { Component, OnInit, Inject } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ApiService } from './../../api.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

@Component({
  selector: 'app-view-bg',
  templateUrl: './view-bg.component.html',
  styleUrls: ['./view-bg.component.css']
})
export class ViewBgComponent implements OnInit {

 /*  employees = [
    {employeeId:611926,firstName:"Patricia",lastName:"ACOSTA",middleName:'Dennis',emailId:'dennis@123',ssnNumber:"835415922",agencyName:"Caprock Home Health Services",bgvDate:"2019-12-16",bgvResult:"PASS"},
    {employeeId:789,firstName:"Patricia",lastName:"ACOSTA",middleName:'Jcob',emailId:'thomas@78',ssnNumber:"835415922",agencyName:"Caprock Home Health Services",bgvDate:"2019-12-16",bgvResult:"PASS"},
  ]; */
  employees = [];
  employeesBackup = [];
  employeeQuery: '';

  constructor(private apiService: ApiService,  private snackBar: MatSnackBar, public dialog: MatDialog) { }

  ngOnInit() {
    this.fetchEmployees();
       /*  this.employees = this.employees.map(employee => {
          if (employee.agency.length) {
            employee['agencyName'] = employee.agency[0].agencyName;
          } else {
            employee['agencyName'] = '';
          }
          return employee;
        }) 
        this.employeesBackup = JSON.parse(JSON.stringify(this.employees)); */
  }

  searchEmployee() {
    if (this.employeeQuery === '') {
      this.employees = [...this.employeesBackup];
    } else {
      const arrayToReturn = this.employeesBackup.filter(row => {
      const columns = ['firstName','lastName','emailId','ssnNumber', 'agencyName'];
        return (columns.map(column => {
          return row[column]
        }).toString().toLowerCase().indexOf(this.employeeQuery.toString().toLowerCase())) > -1;
      });
      this.employees = arrayToReturn;
    }
  }


  fetchEmployees() {
    const sub = this.apiService.fetchEmployeeBgList().subscribe(data => {
      const response: any = data;
      let employees = [];
      if (response.length) {
		  console.log(response);
		  employees = response.filter(item => item.active !== 'NOT_STARTED');
		  this.employees = employees;
       // employees = response.filter(item => item.active === 'S');
       // this.employees = employees;
        /* this.employees = this.employees.map(employee => {
          if (employee.agency.length) {
            employee['agencyName'] = employee.agency[0].agencyName;
          } else {
            employee['agencyName'] = '';
          }
          return employee;
        }) */
        this.employeesBackup = JSON.parse(JSON.stringify(this.employees));
      //   console.log(this.employees, 'employeelist');
      } else {
        this.employees = []
        this.employeesBackup = []
      }
    }, (error) =>  {
      console.log(error);
    //  this.openSnackBar(error.error.message, 'errorSnackbar');
    }, () => {
      console.log('employee fetch complete');

    });
  }

  openSnackBar(message, className) {
    this.snackBar.open(message, null, { duration: 5000, panelClass: [className], horizontalPosition : 'right' });
  }

  viewBgvProof(row) {
    this.apiService.fetchBgvProof(row.employeeId).subscribe(data => {
      this.openDialog(data);
    });
  }

  openDialog(row): void {
    const dialogRef = this.dialog.open(ViewProofDialog, {
      width: '90vw',
      maxWidth: '90vw',
      minHeight: '90vh',
      data: {response: row},
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        //this.deleteEmployee(row);
      }
    });
  }

}



@Component({
  selector: 'dialog-overview-example-dialog',
  templateUrl: './viewBgProof.html',
  styles: [
    `.listItem:hover {
      background: rgba(0,0,0,0.05);
      cursor: pointer;
    }
    .selected {
      background: rgba(0,0,0,0.05);
    }`
  ]
})

export class ViewProofDialog implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<ViewProofDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any, private sanitizer: DomSanitizer, private apiService: ApiService) {}

    currentImageUrl = null;
    currentImageName = null;

  onNoClick(): void {
    this.dialogRef.close();
  }

  selectImage(image) {
    this.currentImageUrl = this.sanitizer.bypassSecurityTrustUrl('data:image/bmp;base64,' + image.imageData);
    this.currentImageName = image.bgDateBaseId;
  }

  ngOnInit() {
    this.currentImageUrl = this.sanitizer.bypassSecurityTrustUrl('data:image/bmp;base64,' + this.data.response[0].imageData);
    this.currentImageName = this.data.response[0].bgDateBaseId;
  }

}