import { Component, OnInit } from '@angular/core';
import { ApiService } from './../../api.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-view-bg',
  templateUrl: './view-bg.component.html',
  styleUrls: ['./view-bg.component.css']
})
export class ViewBgComponent implements OnInit {

  employees = [
        {
      firstName: 'Jeelani',
      middleName: 'Basha',
      lastName: 'Shaik',
      ssnNumber: '123456789',
      emailId: 'jeelanshaik07@gmail.com',
      employeeId: 1,
      alias: 'jillu',
      agency: [{agencyName:'Apolo', agencyId: 12}],
      discipline: {disciplineValue:'Hero', disciplineId: 121},
      dateOfBirth: new Date(),
      address : {addressLine1: '16/165-232', addressLine2: 'anjali Nagar', city: 'Guntakal', state: 'Andhra', country: 'india', zip: 515801}
    },
    {
      firstName: 'Sai',
      middleName: 'Vempalli',
      lastName: 'Krishna',
      ssnNumber: '41234878',
      alias: 'dubbodu',
      emailId: 'saiKrishna@gmail.com',
      employeeId: 2,
      agency: [{agencyName:'MRF', agencyId: 34}],
      discipline: {disciplineValue:'Super-Hero', disciplineId: 343},
      dateOfBirth: new Date(),
      address : {addressLine1: '13/789-146', addressLine2: 'Bhagya Nagar', city: 'Anantapur', state: 'Tamil Nadu', country: 'mexico', zip: 78978}
    },
    {
      firstName: 'Pavan',
      middleName: 'Pothuraju',
      lastName: 'Kumar',
      ssnNumber: '214587147',
      alias: 'tikkodu',
      emailId: 'pavankumar@gmail.com',
      employeeId: 3,
      agency: [{agencyName:'Ceat', agencyId: 78}],
      discipline: {disciplineValue:'Villain', disciplineId: 565},
      dateOfBirth: new Date(),
      address : {addressLine1: '787/gf', addressLine2: 'Karapakkam', city: 'Chennai', state: 'venice', country: 'canada', zip: 45612}
    },
    {
      firstName: 'John',
      middleName: 'Henry',
      lastName: 'Doe',
      ssnNumber: '8757842',
      alias: 'jh',
      emailId: 'johndoe@gmail.com',
      employeeId: 4,
      agency: [{agencyName:'Michellin', agencyId: 56}],
      discipline: {disciplineValue:'Super-Villain', disciplineId: 787},
      dateOfBirth: new Date(),
      address : {addressLine1: 'asd/123', addressLine2: 'v.cmn.a', city: 'Puducherry', state: 'Mumbai', country: 'Australia', zip: 139897}
    },
    {
      firstName: 'Milton',
      middleName: 'Bascon',
      lastName: 'Henry',
      alias: 'bully',
      ssnNumber: '987135412',
      emailId: 'henrymilton@gmail.com',
      employeeId: 5,
      agency: [{agencyName:'MRF', agencyId: 34}],
      discipline: {disciplineValue:'Villian', disciplineId: 565},
      dateOfBirth: new Date(),
      address : {addressLine1: 'qwefd4/467', addressLine2: 'Shollingnallur', city: 'Madurai', state: 'Keral', country: 'Africa', zip: 12345}
    }
  ];
  employeesBackup = [];
  employeeQuery: '';

  constructor(private apiService: ApiService,  private snackBar: MatSnackBar) { }

  ngOnInit() {
    this.fetchEmployees();
        this.employees = this.employees.map(employee => {
          if (employee.agency.length) {
            employee['agencyName'] = employee.agency[0].agencyName;
          } else {
            employee['agencyName'] = '';
          }
          return employee;
        })
        this.employeesBackup = JSON.parse(JSON.stringify(this.employees));
  }

  searchEmployee() {
    if (this.employeeQuery === '') {
      this.employees = [...this.employeesBackup];
    } else {
      const arrayToReturn = this.employeesBackup.filter(row => {
      const columns = ['firstName','lastName','emailId','ssnNumber', 'agencyName'];
        return (columns.map(column => {
          return row[column]
        }).toString().toLowerCase().indexOf(this.employeeQuery.toString().toLowerCase())) > -1;
      });
      this.employees = arrayToReturn;
    }
  }


  fetchEmployees() {
    const sub = this.apiService.fetchEmployeeBgList().subscribe(data => {
      const response: any = data;
      let employees = [];
      if (response.length) {
        employees = response.filter(item => item.active === 'S');
        this.employees = employees;
        this.employees = this.employees.map(employee => {
          if (employee.agency.length) {
            employee['agencyName'] = employee.agency[0].agencyName;
          } else {
            employee['agencyName'] = '';
          }
          return employee;
        })
        this.employeesBackup = JSON.parse(JSON.stringify(this.employees));
      //   console.log(this.employees, 'employeelist');
      } else {
        this.employees = []
        this.employeesBackup = []
      }
    }, (error) =>  {
      console.log(error);
      this.openSnackBar(error.error.message, 'errorSnackbar');
    }, () => {
      console.log('employee fetch complete');

    });
  }

  openSnackBar(message, className) {
    this.snackBar.open(message, null, { duration: 5000, panelClass: [className], horizontalPosition : 'right' });
  }

}
