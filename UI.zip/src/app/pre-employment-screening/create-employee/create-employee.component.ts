import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { ApiService } from './../../api.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {
  toggleType1 = 'password';
  createEmployeeForm: FormGroup;
  maxDate = new Date();
  showSpinner = false;
  agencyId = null;
  designationId = null;
  get f() { return this.createEmployeeForm.controls; }


 
  agencyList = [];
  designationList = [];


/* agencyList = [
  {agencyId: 12, agencyName: 'Apollo'},
  {agencyId: 34, agencyName: 'MRF'},
  {agencyId: 56, agencyName: 'Michellin'},
  {agencyId: 78, agencyName: 'Ceat'}
]; 
  designationList = [
    {disciplineId: 12, disciplineValue: 'Hero'},
    {disciplineId: 34, disciplineValue: 'Super-Hero'},
    {disciplineId: 56, disciplineValue: 'Villian'},
    {disciplineId: 78, disciplineValue: 'Super-Villian'},
  ]; */

  constructor(private apiService: ApiService, private formBuilder: FormBuilder,  private snackBar: MatSnackBar, private router: Router) { }

  ngOnInit() {
   this.initiateForm();
   this.fetchAgencyList();
   this.fetchDesignationList();
  }

  initiateForm() {
    this.createEmployeeForm = this.formBuilder.group({
      ssnNumber: ['', Validators.required],
      firstName: ['', Validators.required],
      middleName: '',
      lastName: ['', Validators.required],
      alias : [''],
      emailId: ['', [Validators.required, Validators.email]],
      dateOfBirth: ['', Validators.required],
      agencyId: ['', Validators.required],
      designationId: ['', Validators.required],
      addressLine1: ['', Validators.required],
      addressLine2: [''],
      rcity: ['', Validators.required],
      rstate: ['', Validators.required],
      rzipCode: ['', Validators.required],
      rcountry: ['', Validators.required],
  });
  }

  fetchAgencyList() {
    this.showSpinner = true;
    const sub = this.apiService.fetchAgencyList().subscribe(data => {
      console.log(data);
      const response: any = data;
      this.showSpinner = false;
      this.agencyList = response;
    }, (error) =>  {
      console.log(error);
      this.openSnackBar(error.error.message, 'errorSnackbar');
      this.showSpinner = false;
    }, () => {
      console.log('agency fetch success');
      this.showSpinner = false;
    });
  }

  fetchDesignationList() {
    this.showSpinner = true;
    const sub = this.apiService.fetchDesignationList().subscribe(data => {
      console.log(data);
      const response: any = data;
      this.showSpinner = false;
      this.designationList = response;
    }, (error) =>  {
      console.log(error);
      this.openSnackBar(error.error.message, 'errorSnackbar');
      this.showSpinner = false;
    }, () => {
      console.log('agency fetch success');
      this.showSpinner = false;
    });
  }

  showPassword1() {
    setTimeout(() => {
      this.toggleType1 = 'password';
    }, 1000);
    this.toggleType1 = 'text';
  }

  createEmployee() {
    console.log(this.createEmployeeForm.value);
    this.showSpinner = true;
    const requestBody = {...this.createEmployeeForm.value};
    requestBody.alias = { aliasName: this.createEmployeeForm.value.alias };
    requestBody.agency = [{agencyId: this.agencyId}];
    requestBody.discipline =  {disciplineId: this.designationId ,disciplineValue:this.designationList.filter(item=> item.disciplineId===this.designationId)[0].disciplineValue};
    requestBody.address = {
      addressLine1: this.createEmployeeForm.value.addressLine1,
      addressLine2: this.createEmployeeForm.value.addressLine2,
      city: this.createEmployeeForm.value.rcity,
      state: this.createEmployeeForm.value.rstate,
      country: this.createEmployeeForm.value.rcountry,
      zip: Number(this.createEmployeeForm.value.rzipCode),
    },
    delete requestBody.agencyId;
    delete requestBody.designationId;
    delete requestBody.addressLine1;
    delete requestBody.addressLine2;
    delete requestBody.rcity;
    delete requestBody.rstate;
    delete requestBody.rcountry;
    delete requestBody.rzipCode;
    console.log(requestBody);
    const sub = this.apiService.createEmployee(requestBody).subscribe(data => {
      console.log(data);
      const response: any = data;
      this.openSnackBar(response.message, 'successSnackbar');
      this.showSpinner = false;
      this.initiateForm();
      this.router.navigateByUrl('preEmpScreening');
    }, (error) =>  {
      console.log(error);
      this.openSnackBar(error.error.message, 'errorSnackbar');
      this.showSpinner = false;
     // this.initiateForm();
    }, () => {
      console.log('create employee success');
      this.showSpinner = false;
    });
  }

  openSnackBar(message, classnNumberame) {
    this.snackBar.open(message, null, { duration: 5000, panelClass: [classnNumberame], horizontalPosition : 'right' });
  }

  resetForm() {
    this.showSpinner = false;
    this.agencyId = null;
    this.designationId = null;
    this.initiateForm();
  }

  agencyChange(event) {
    this.agencyId = event;
  }

  designationChange(event) {
    this.designationId = event;
  }
}
