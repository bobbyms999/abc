import { Component, OnInit, Inject } from '@angular/core';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { ApiService } from './../../api.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

@Component({
  selector: 'app-manage-employee',
  templateUrl: './manage-employee.component.html',
  styleUrls: ['./manage-employee.component.css']
})
export class ManageEmployeeComponent implements OnInit {
  editEmployeeForm: FormGroup;
  employeeList = [];
  canDelete = false;
  showSpinner = false;
  agencyId = null;
  designationId = null;
   designationList = [];
  agencyList = []; 

 /*  agencyList = [
    {agencyId: 12, agencyName: 'Apollo'},
    {agencyId: 34, agencyName: 'MRF'},
    {agencyId: 56, agencyName: 'Michellin'},
    {agencyId: 78, agencyName: 'Ceat'}
  ];

    designationList = [
      {disciplineId: 121, disciplineValue: 'Hero'},
      {disciplineId: 343, disciplineValue: 'Super-Hero'},
      {disciplineId: 565, disciplineValue: 'Villian'},
      {disciplineId: 787, disciplineValue: 'Super-Villian'},
    ]; */

  get f() { return this.editEmployeeForm.controls; }
  maxDate = new Date();

  employees = [
    /*    {
      firstName: 'Jeelani',
      middleName: 'Basha',
      lastName: 'Shaik',
      ssnNumber: '123456789',
      emailId: 'jeelanshaik07@gmail.com',
      employeeId: 1,
      alias: 'jillu',
      agency: [{agencyName:'Apolo', agencyId: 12}],
      discipline: {disciplineValue:'Hero', disciplineId: 121},
      dateOfBirth: new Date(),
      address : {addressLine1: '16/165-232', addressLine2: 'anjali Nagar', city: 'Guntakal', state: 'Andhra', country: 'india', zip: 515801}
    },
    {
      firstName: 'Sai',
      middleName: 'Vempalli',
      lastName: 'Krishna',
      ssnNumber: '41234878',
      alias: 'dubbodu',
      emailId: 'saiKrishna@gmail.com',
      employeeId: 2,
      agency: [{agencyName:'MRF', agencyId: 34}],
      discipline: {disciplineValue:'Super-Hero', disciplineId: 343},
      dateOfBirth: new Date(),
      address : {addressLine1: '13/789-146', addressLine2: 'Bhagya Nagar', city: 'Anantapur', state: 'Tamil Nadu', country: 'mexico', zip: 78978}
    },
    {
      firstName: 'Pavan',
      middleName: 'Pothuraju',
      lastName: 'Kumar',
      ssnNumber: '214587147',
      alias: 'tikkodu',
      emailId: 'pavankumar@gmail.com',
      employeeId: 3,
      agency: [{agencyName:'Ceat', agencyId: 78}],
      discipline: {disciplineValue:'Villain', disciplineId: 565},
      dateOfBirth: new Date(),
      address : {addressLine1: '787/gf', addressLine2: 'Karapakkam', city: 'Chennai', state: 'venice', country: 'canada', zip: 45612}
    },
    {
      firstName: 'John',
      middleName: 'Henry',
      lastName: 'Doe',
      ssnNumber: '8757842',
      alias: 'jh',
      emailId: 'johndoe@gmail.com',
      employeeId: 4,
      agency: [{agencyName:'Michellin', agencyId: 56}],
      discipline: {disciplineValue:'Super-Villain', disciplineId: 787},
      dateOfBirth: new Date(),
      address : {addressLine1: 'asd/123', addressLine2: 'v.cmn.a', city: 'Puducherry', state: 'Mumbai', country: 'Australia', zip: 139897}
    },
    {
      firstName: 'Milton',
      middleName: 'Bascon',
      lastName: 'Henry',
      alias: 'bully',
      ssnNumber: '987135412',
      emailId: 'henrymilton@gmail.com',
      employeeId: 5,
      agency: [{agencyName:'MRF', agencyId: 34}],
      discipline: {disciplineValue:'Villian', disciplineId: 565},
      dateOfBirth: new Date(),
      address : {addressLine1: 'qwefd4/467', addressLine2: 'Shollingnallur', city: 'Madurai', state: 'Keral', country: 'Africa', zip: 12345}
    }   */
  ];
  employeesBackup = [];
  employeeQuery: '';
  isEdit =  false;
  currentEmployee;
  selected = [];

  onSelect({ selected }) {
    //console.log('Select Event', selected, this.selected);
    this.selected.splice(0, this.selected.length);
    this.selected.push(...selected);
  }

  selectRow(event, row) {
    if (event.checked) {
      row.isSelected = true;
      this.selected = [...this.selected, row];
    } else {
      row.isSelected = false;
      this.selected = this.selected.filter(item => item.isSelected);
    }
    console.log(this.selected)
  }

    
    constructor(private formBuilder: FormBuilder, private apiService: ApiService, private snackBar: MatSnackBar, public dialog: MatDialog) { }

  ngOnInit() {
    this.fetchAgencyList();
	this.fetchDesignationList();
    this.editEmployeeForm = this.formBuilder.group({
      ssnNumber: ['', Validators.required],
      firstName: ['', Validators.required],
      middleName: [''],
      alias: [''],
      agencyId: ['', Validators.required],
      designationId: ['', Validators.required],
      lastName: ['', Validators.required],
      emailId: ['', [Validators.required, Validators.email]],
      dateOfBirth: ['', Validators.required],
      addressLine1: ['', Validators.required],
      addressLine2: [''],
      rcity: ['', Validators.required],
      rstate: ['', Validators.required],
      rzipCode: ['', Validators.required],
      rcountry: ['', Validators.required],
   /*    agencyId: ['', Validators.required],
      designationId: ['', Validators.required], */
  });
    this.fetchEmployees();
   /*  this.employees = this.employees.map(employee => {
      if (employee.agency.length) {
        employee['agencyName'] = employee.agency[0].agencyName;
      } else {
        employee['agencyName'] = '';
      }
      return employee;
    })
    this.employeesBackup = JSON.parse(JSON.stringify(this.employees)); */
  }

  fetchEmployees() {
    const sub = this.apiService.fetchEmployeeList().subscribe(data => {
      const response: any = data;
      let employees = [];
      if (response.length) {
        employees = response.filter(item => item.active === 'S');
        this.employees = employees;
        this.employees = this.employees.map(employee => {
          if (employee.agency.length) {
            employee['agencyName'] = employee.agency[0].agencyName;
          } else {
            employee['agencyName'] = '';
          }
          return employee;
        })
        this.employeesBackup = JSON.parse(JSON.stringify(this.employees));
      //   console.log(this.employees, 'employeelist');
      } else {
        this.employees = []
        this.employeesBackup = []
      }
    }, (error) =>  {
      console.log(error);
      this.openSnackBar(error.error.message, 'errorSnackbar');
    }, () => {
      console.log('employee fetch complete');

    });
  }

  searchEmployee() {
    if (this.employeeQuery === '') {
      this.employees = [...this.employeesBackup];
    } else {
      const arrayToReturn = this.employeesBackup.filter(row => {
      const columns = ['firstName','lastName','emailId','ssnNumber', 'agencyName'];
        return (columns.map(column => {
          return row[column]
        }).toString().toLowerCase().indexOf(this.employeeQuery.toString().toLowerCase())) > -1;
      });
      this.employees = arrayToReturn;
    }
  }

  editEmployee(employee) {
    console.log(employee);
    this.isEdit = true;
    this.currentEmployee = employee;
    this.editEmployeeForm = this.formBuilder.group({
      ssnNumber: [this.currentEmployee.ssnNumber, Validators.required],
      firstName: [this.currentEmployee.firstName, Validators.required],
      middleName: this.currentEmployee.middleName,
      lastName: [this.currentEmployee.lastName, Validators.required],
      alias: [this.currentEmployee.aliasSpecific],
      agencyId: [this.currentEmployee.agency[0].agencyId, Validators.required],
      designationId: [this.currentEmployee.discipline.disciplineId, Validators.required],
      emailId: [this.currentEmployee.emailId, [Validators.required, Validators.email]],
      dateOfBirth: [this.currentEmployee.dateOfBirth, Validators.required],
      addressLine1: [this.currentEmployee.address.addressLine1, Validators.required],
      addressLine2: [this.currentEmployee.address.addressLine2],
      rcity: [this.currentEmployee.address.city, Validators.required],
      rstate: [this.currentEmployee.address.state, Validators.required],
      rzipCode: [this.currentEmployee.address.zip, Validators.required],
      rcountry: [this.currentEmployee.address.country, Validators.required]
  });
    this.agencyId = this.currentEmployee.agency[0].agencyId;
    this.designationId = this.currentEmployee.discipline.disciplineId;
  }

  deleteEmployee(employee) {
    const { employeeId } = employee;
  //  const newEmployeeList = this.employees.filter(e => e.ssn !== ssn);
  //  this.employees = newEmployeeList;
    const requestBody = { employeeId };
    this.showSpinner = true;
    const sub = this.apiService.deleteEmployee(employeeId).subscribe(data => {
      const response: any = data;
      if (response.code === 1) {
        this.openSnackBar(response.message, 'successSnackbar');
	      this.fetchEmployees();
      } else if (response.code === 0) {
        this.openSnackBar(response.message, 'errorSnackbar');
      }
      this.showSpinner = false;
    }, (error) =>  {
      console.log(error);
      this.openSnackBar(error.error.message, 'errorSnackbar');
      this.showSpinner = false;
    }, () => {
      console.log('employee delete complete');
    });

  }

  saveEditing() {
    //console.log(this.editEmployeeForm.value);
    this.createEmployee();
  }

  openSnackBar(message, className) {
    this.snackBar.open(message, null, { duration: 5000, panelClass: [className], horizontalPosition : 'right' });
  }

 
createEmployee() {
    const requestBody = {...this.editEmployeeForm.value, employeeId: this.currentEmployee.employeeId };
    requestBody.agency = [{agencyId: this.currentEmployee.agency.length ? this.currentEmployee.agency[0].agencyId : 0}];
    requestBody.discipline =  {disciplineId: this.currentEmployee.discipline.disciplineId,disciplineValue:this.designationList.filter(item=> item.disciplineId===this.designationId)[0].disciplineValue};
    requestBody.aliasSpecific = this.editEmployeeForm.value.alias;
    requestBody.address = {
      addressLine1: this.editEmployeeForm.value.addressLine1,
      addressLine2: this.editEmployeeForm.value.addressLine2,
      city: this.editEmployeeForm.value.rcity,
      state: this.editEmployeeForm.value.rstate,
      country: this.editEmployeeForm.value.rcountry,
      zip: Number(this.editEmployeeForm.value.rzipCode),
    },
    delete requestBody.addressLine1;
    delete requestBody.addressLine2;
    delete requestBody.rcity;
    delete requestBody.rstate;
    delete requestBody.rcountry;
    delete requestBody.rzipCode;
    delete requestBody.agencyId;
    delete requestBody.designationId;
    this.showSpinner = true;
    console.log(requestBody, 'requestBody');
    const sub = this.apiService.createEmployee(requestBody).subscribe(data => {
     // console.log(data);
      const response: any = data;
      if (response.code === 1) {
        this.openSnackBar('Employee updated successfully', 'successSnackbar');
	      this.fetchEmployees();
        this.isEdit = false;
      } else if (response.code === 0) {
      this.openSnackBar('Employee update failed', 'errorSnackbar');
      }
      this.showSpinner = false;
    }, (error) =>  {
      console.log(error);
      this.openSnackBar(error.error.message, 'errorSnackbar');
      this.showSpinner = false;
    }, () => {
      console.log('create employee success');
      this.isEdit = false;
    });
  }

  openDialog(row): void {
    const dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
      width: '350px',
      minHeight: '150px',
      data: {...row}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.deleteEmployee(row);
      }
    });
  }

  agencyChange(event) {
    this.currentEmployee.agency = [{agencyId: event}];
    this.agencyId = event;
  }

  designationChange(event) {
    this.currentEmployee.discipline = { disciplineId: event };
    this.designationId = event;
  }

  fetchAgencyList() {
    this.showSpinner = true;
    const sub = this.apiService.fetchAgencyList().subscribe(data => {
      console.log(data);
      const response: any = data;
      this.showSpinner = false;
      this.agencyList = response;
    }, (error) =>  {
      console.log(error);
      this.openSnackBar(error.error.message, 'errorSnackbar');
      this.showSpinner = false;
    }, () => {
      console.log('agency fetch success');
      this.showSpinner = false;
    });
  }

  fetchDesignationList() {
    this.showSpinner = true;
    const sub = this.apiService.fetchDesignationList().subscribe(data => {
      console.log(data);
      const response: any = data;
      this.showSpinner = false;
      this.designationList = response;
    }, (error) =>  {
      console.log(error);
      this.openSnackBar(error.error.message, 'errorSnackbar');
      this.showSpinner = false;
    }, () => {
      console.log('agency fetch success');
      this.showSpinner = false;
    });
  }

}


@Component({
  selector: 'dialog-overview-example-dialog',
  template: `
  <div style="display:flex;justify-content:center;align-items:center;flex-direction:column">
  <h1 mat-dialog-title>Delete Confirmation</h1>
  <div mat-dialog-content>
    <p>Are you sure to delete the user?</p>
  </div>
  <div mat-dialog-actions>
    <button mat-button (click)="onNoClick()">Cancel</button>
    <button mat-button [mat-dialog-close]="true">Delete</button>
  </div>
  </div>
  `,
})

export class DialogOverviewExampleDialog {

  constructor(
    public dialogRef: MatDialogRef<DialogOverviewExampleDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) {}

  onNoClick(): void {
    this.dialogRef.close();
  }

}