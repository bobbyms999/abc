import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpRequest, HttpEventType, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { of } from 'rxjs';
import { catchError, last, map, tap } from 'rxjs/operators';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

@Component({
  selector: 'app-upload-static-alias',
  templateUrl: './upload-static-alias.component.html',
  styleUrls: ['./upload-static-alias.component.css']
})
export class UploadStaticAliasComponent implements OnInit {

  fileUploadProgress = 0;
  fileUploadComplete = false;

  openSnackBar(message, className) {
    this.snackBar.open(message, null, { duration: 5000, panelClass: [className] });
  }

  constructor(private http: HttpClient, private snackBar: MatSnackBar,private router: Router) { }

  ngOnInit() {
  }

  onClick() {
    const fileUpload = document.getElementById('fileUploadAlias') as HTMLInputElement;
    fileUpload.onchange = () => {
      const file = fileUpload.files[0];
      this.uploadFile(file);
    };
    fileUpload.click();
  }

  uploadFile(fileToUpload) {
    const fd = new FormData();
    fd.append('file', fileToUpload);

    const req = new HttpRequest('POST', 'http://localhost:2020/accredilinkdb/file/uploadaliasnames', fd, {
      reportProgress: true
    });

    fileToUpload.inProgress = true;
    fileToUpload.sub = this.http.request(req).pipe(
      map(event => {
        switch (event.type) {
          case HttpEventType.UploadProgress:
            fileToUpload.progress = Math.round(event.loaded * 100 / event.total);
            console.log(fileToUpload.progress, 'progress');
            this.fileUploadProgress = fileToUpload.progress;
            break;
          case HttpEventType.Response:
            return event;
        }
      }),
      tap(message => { }),
      last(),
      catchError((error: HttpErrorResponse) => {
        fileToUpload.inProgress = false;
        fileToUpload.canRetry = true;
        this.fileUploadComplete = true;
        this.openSnackBar('File Uploaded Failed', 'errorSnackbar');
        return of(`${fileToUpload.name} upload failed.`);
		this.router.navigateByUrl('preEmpScreening');
      })
    ).subscribe(
      (event: any) => {
        if (typeof (event) === 'object') {
          console.log('file upload success');
          this.fileUploadProgress = 0;
          this.fileUploadComplete = false;
          this.openSnackBar('File Uploaded Successfully', 'successSnackbar');
		  this.router.navigateByUrl('preEmpScreening');
        }
      }
    );
  }

}
