package com.accredilink.bgv.service;

import com.accredilink.bgv.util.ResponseObject;

public interface BgCheckService {

	public ResponseObject submitBg(int employeeId);

}
