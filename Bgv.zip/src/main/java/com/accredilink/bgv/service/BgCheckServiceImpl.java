package com.accredilink.bgv.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accredilink.bgv.component.NationalOIGCheck;
import com.accredilink.bgv.entity.Employee;
import com.accredilink.bgv.repository.EmployeeRepository;
import com.accredilink.bgv.util.ResponseObject;

@Service
public class BgCheckServiceImpl implements BgCheckService {

	@Override
	public ResponseObject submitBg(int employeeId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	/*
	 * @Autowired private EmployeeRepository employeeRepository;
	 * 
	 * @Autowired private NationalOIGCheck nationalOIGCheck;
	 * 
	 * @Override public ResponseObject submitBg(int employeeId) { Optional<Employee>
	 * employee = employeeRepository.findById(employeeId);
	 * 
	 * if (employee.isPresent()) { boolean status =
	 * nationalOIGCheck.check(employee.get()); return (status) ?
	 * ResponseObject.constructResponse("Processed Successfully", 1) :
	 * ResponseObject.constructResponse("unable to process", 0); } else { return
	 * ResponseObject.constructResponse("Employee is not avilable", 0); } }
	 */}
