package com.accredilink.bgv.component;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accredilink.bgv.entity.Employee;
import com.accredilink.bgv.util.ScreenShot;

@Component
public class NationalOIGCheck {
	/*
	 * private static final String URL = "https://exclusions.oig.hhs.gov/";
	 * 
	 * @Autowired private WebDriver driver;
	 * 
	 * public boolean check(Employee employee) { boolean status = false;
	 * 
	 * driver.get(URL);
	 * driver.findElement(By.id("ctl00_cpExclusions_txtSPLastName")).sendKeys(
	 * employee.getLastName());
	 * driver.findElement(By.id("ctl00_cpExclusions_txtSPFirstName")).sendKeys(
	 * employee.getFirstName());
	 * driver.findElement(By.id("ctl00_cpExclusions_ibSearchSP")).click(); try {
	 * driver.findElement(By.xpath("//*[@id='ctl00_cpExclusions_P1']/strong")).
	 * getText(); ScreenShot.takescreenshot(driver, employee.getEmployeeId() + "-" +
	 * employee.getFirstName()); status = true; } catch (NoSuchElementException e) {
	 * driver.findElement(By.linkText("Verify")).click();
	 * driver.findElement(By.id("ctl00_cpExclusions_txtSSN")).sendKeys(employee.
	 * getSsnNumber());
	 * driver.findElement(By.id("ctl00_cpExclusions_ibtnVerify")).click(); try {
	 * Thread.sleep(6000); } catch (InterruptedException ie) { e.printStackTrace();
	 * } ScreenShot.takescreenshot(driver, employee.getEmployeeId() + "-" +
	 * employee.getFirstName()); status = true; } return status; }
	 */}
