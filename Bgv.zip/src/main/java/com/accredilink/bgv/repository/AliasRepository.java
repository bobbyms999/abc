package com.accredilink.bgv.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.accredilink.bgv.entity.Alias;

public interface AliasRepository extends JpaRepository<Alias, Integer> {

}
