package com.accredilink.bgv.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.accredilink.bgv.entity.DataFeedEmployee;

public interface DataFeedEmployeeRepo extends JpaRepository<DataFeedEmployee, String>{
	

}
