package com.accredilink.bgv.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;

import com.accredilink.bgv.entity.EmployeeBgDetails;

public interface EmployeeBgDetailsRepository extends JpaRepository<EmployeeBgDetails, Date> {

}
