package com.accredilink.bgv.component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accredilink.bgv.entity.Alias;
import com.accredilink.bgv.entity.Discipline;
import com.accredilink.bgv.entity.Employee;
import com.accredilink.bgv.repository.AliasRepository;
import com.accredilink.bgv.repository.DisciplineRepository;
import com.accredilink.bgv.repository.EmployeeRepository;

@Component
public class DisciplineDataLoading {

	@Autowired
	private DisciplineRepository disciplineRepository;

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	AliasRepository aliasRepository;

	private final Map<String, Integer> dataMap = new HashMap<String, Integer>();
	private List<Discipline> disciplines;
	private final List<String> firstNamlst = new ArrayList<>();
	private List<Employee> employees;
	
	/*
	 * While startup of the application loading the data
	 */
	@PostConstruct
	public void init() {
		//loading discipline table data
		disciplines = disciplineRepository.findAll();
		disciplines.forEach(discipline -> {
			dataMap.put(discipline.getDisciplineValue(), discipline.getDisciplineId());
		});

		// added for aliaslist
		employees = employeeRepository.findAll();
		employees.forEach(employees -> {
			firstNamlst.add(employees.getFirstName());
		});

	}

	public Map<String, Integer> getData() {
		return dataMap;
	}
	
	public List<Discipline> fetchAllDisciplines(){
		return disciplines;
	}

	public List<String> fetchFirstNamelist() {
		return firstNamlst;
	}

	public Employee findbyFirstName(String firstName) {
		return employeeRepository.findByFirstName(firstName);

	}

	public Optional<Alias> findById(int id) {
		return aliasRepository.findById(id);
	}

	public void saveEmployeeData(Employee emp) {
		employeeRepository.save(emp);
	}

	public void saveAliasData(Alias alias) {
		aliasRepository.save(alias);
	}

}
